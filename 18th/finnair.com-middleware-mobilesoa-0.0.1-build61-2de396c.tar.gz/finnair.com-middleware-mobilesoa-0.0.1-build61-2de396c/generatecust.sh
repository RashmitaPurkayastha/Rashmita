#!/bin/sh
xsltproc -stringparam envname dev -stringparam environment Environment.xml Customization.xsl Services.xml > kustomoi.xml

#!/bin/sh

for ENV in dev preprod preprodibm proda prodb prod-a-ibm prod-b-ibm
do
	mkdir -p ../target/customizationFiles/$ENV
	xsltproc -stringparam envname $ENV -stringparam environment Environment.xml Customization.xsl Services.xml > ../target/customizationFiles/$ENV/MobileSOACustomization.xml
done
