#!/bin/sh
# This script helps in copying the required hotfix modifications in place 
## Get the absolutepath to installation directory
INSTALLDIR=$(cd $(dirname "$0") && pwd -P)
DATE=`date +%Y_%m_%d_%H\:%M\:%S`
LOGFILE="OSB_install_${DATE}.log"
STATUSFILE=$INSTALLDIR/status
ENV=$1
WLSONLY=$2

# Check first environment
case "$ENV" in 
dev)
MW_HOME=/home/Oracle/Middleware
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/Oracle_OSB1
;;
preprod)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
preprodibm)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
proda)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
prodb)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
*)
  echo "Usage: ./`basename $0` <dev|preprod|preprodibm|proda|prodb> [wlsconfig]";
  echo "   - if wlsconfig parameter present, only WLS related configurations are executed"
  exit;
;;
esac

function log {
	echo `date +"%d.%m.%Y %H:%M:%S": ` "$@"
}

rm $STATUSFILE

{
	log Starting installation
	WLST=$MW_HOME/wlserver_10.3/common/bin/wlst.sh
	log WLST started from: $WLST
	#Set domain env
	. $DOMAIN_HOME/bin/setDomainEnv.sh

	# Copy properties files
	log Copying properties files...
	cp $INSTALLDIR/domain/$ENV/*.properties $DOMAIN_HOME/
	if [ $? -ne 0 ]; then
		echo "Copying properties failed.Exiting";
		return 1;
	fi
	cp $INSTALLDIR/domain/$ENV/*.xml $DOMAIN_HOME/
	if [ $? -ne 0 ]; then
		echo "Copying files failed.Exiting";
		return 1;
	fi

	# Copying all XPath customizations
	log Copying all XPath customizations
	cp $INSTALLDIR/osb_xpath/* $OSB_HOME/config/xpath-functions/
	if [ $? -ne 0 ]; then
		echo "Copying files failed.Exiting";
		return 1;
	fi
	
	# VVV !!! airports_overrides.properties HACK BELOW NEEDS TO BE CHANGED WHEN A PIPELINE HAS BEEN CREATED FOR MANAGING COMMON MODULES AND DEPENDENCIES !!! VVV
	
	# Moving the airports_overrides.properties to outside the jar file
	log Moving the airports_overrides.properties to outside the jar file
	if [ -f $DOMAIN_HOME/airports_overrides.properties ]; then
	  # making a backup of the properties file so if there is some local change that we've neglected to add to version control, we can restore it
	  mkdir -p $OSB_HOME/config/xpath-functions/backups
	  cp $DOMAIN_HOME/airports_overrides.properties $OSB_HOME/config/xpath-functions/backups/backed_up_`date +%Y-%m-%d_%T`_airports_overrides.properties
	fi
	# extract the properties file and put it in the domain home folder (on the classpath)
	unzip -o $OSB_HOME/config/xpath-functions/CustomXPath.jar airports_overrides.properties -d $DOMAIN_HOME
	if [ $? -ne 0 ]; then
	  echo "Failed to extract airports_overrides.properties; it will remain in the CustomXPath.jar and can't be"
	  echo "dynamically updated. Any version in the domain home folder will be removed to avoid potential"
	  echo "classpath conflicts (check the backups if you need to restore it)."
	  rm $DOMAIN_HOME/airports_overrides.properties
	else
	  # file extracted, now we should also remove it from the jar to avoid any conflicts (leaving it only in the domain home folder)
	  
	  # making a backup of the jar in case something goes wrong during the modification; the backup will remain until the next install
	  cp $OSB_HOME/config/xpath-functions/CustomXPath.jar $OSB_HOME/config/xpath-functions/backups/CustomXPath.jar.bak
	  
	  # removing the file from the jar
	  zip -d $OSB_HOME/config/xpath-functions/CustomXPath.jar airports_overrides.properties
	  if [ $? -ne 0 ]; then
	    echo "Failed to remove airport_overrides.properties from CustomXPath.jar; the extracted file will be"
	    echo "removed from the domain home folder to avoid potential classpath conflicts (check the backups if"
	    echo "you need to restore it)."
	    rm $DOMAIN_HOME/airports_overrides.properties
	    
	    # also restoring the backup jar in case the properties file removal attempt broke the jar
	    cp $OSB_HOME/config/xpath-functions/backups/CustomXPath.jar.bak $OSB_HOME/config/xpath-functions/CustomXPath.jar
	  fi
	fi

	# Execute resource configuration file
	log Executing configuration to WLS
	$WLST $INSTALLDIR/modifyResources.py $INSTALLDIR/env/${ENV}.properties "$PACKAGE" 2>&1 || echo $? > $STATUSFILE
	if [ -f $STATUSFILE ]; then
		log Failed
		exit $CODE;
	fi
	log Executing security configuration
	$WLST $INSTALLDIR/modifySecurity.py $INSTALLDIR/env/${ENV}.properties $INSTALLDIR/env/${ENV}Security.properties "$PACKAGE" $INSTALLDIR 2>&1 || echo $? > $STATUSFILE
	if [ -f $STATUSFILE ]; then
		log Failed
		exit $CODE;
	fi

	if [ "$WLSONLY" != "wlsconfig" ];
	then
		# Install OSB config jar
		log Starting to install OSB config
		VERSION=`grep -i version $INSTALLDIR/pom.properties | cut -d\= -f2`
		ARTIFACTID=`grep -i artifact $INSTALLDIR/pom.properties | cut -d\= -f2`
		PACKAGE="$ARTIFACTID $VERSION"
		$WLST $INSTALLDIR/importOSBConfig.py $INSTALLDIR/env/${ENV}.properties $INSTALLDIR/osb/MobileSOA.jar "$PACKAGE" 2>&1 || echo $? > $STATUSFILE
		if [ -f $STATUSFILE ]; then
			log Failed
			exit $CODE;
		fi

		# Execute OSB customization files
		log Starting to execute customization files
		CUST_FILES=$INSTALLDIR/osb/customizationFiles/${ENV}/*
		for FILE in $CUST_FILES; do
			log Executing: $FILE;
			COMMENT="$PACKAGE - `basename $FILE`"
			$WLST $INSTALLDIR/importOSBCustomizationFile.py $INSTALLDIR/env/${ENV}.properties $FILE "$COMMENT" 2>&1 || echo $? > $STATUSFILE
			if [ -f $STATUSFILE ]; then
				exit $CODE;
			fi
		done
		if [ -f $STATUSFILE ]; then
			log Failed
			exit $CODE;
		fi
	else
		log OSB configurations skipped.
	fi
	log Installation finished
	log If there was new XPath customizations, remember to restart servers!
} 2>&1 | tee $LOGFILE
if [ -f $STATUSFILE ]; then
	CODE=`cat $STATUSFILE`;
	#rm $STATUSFILE;
	log Installation failed with error code=$CODE
	exit $CODE;
fi
