def log(string):	
    print '   --> ' + string

#===================================================================
# Create a user to WLS
#   - username
#   - password
#   - description
#===================================================================
# atnr.userExists()
# atnr.changeUserPassword()
# atnr.setUserDescription()
def createUser(username, password, description):
	log('Creating user: ' + username)
	atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("DefaultAuthenticator")
	if atnr.userExists(username) == 0:
		atnr.createUser(username,password,description)
		log('...created')
	else:
		log('... already exists, updating password and description')
		atnr.resetUserPassword(username,password)
		atnr.setUserDescription(username,description)
	
#if atnr.isMember('Administrators','my_user',true) == 0:
def addUserToGroup(username, group):
	log("Adding user (" + username + ") to the group (" + group + ")")
	atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("DefaultAuthenticator")
	if atnr.isMember(group,username,true) == 0:
		atnr.addMemberToGroup(group, username)
		log('...added')
	else:
		log('...Already a member of group')

#===================================================================
# Create groups to WLS
#   - groupname
#   - description
#===================================================================
# atnr.groupExists
# atnr.setGroupDescription
def createGroup(group, description):
	atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("DefaultAuthenticator")
	if atnr.groupExists(group) == 0:
		log("Creating group: " + group)
		atnr.createGroup(group,description)
	else:
		log("Updating group description: " + group)
		atnr.setGroupDescription(group, description)	

#===================================================================
# Connect to the Admin Server
#===================================================================

def connectToServer(username, password, url):
    connect(username, password, url)
    #domainRuntime()

	

#====================================================================
# Entry function to configure project configuration and resources
#        into a domain
#====================================================================

def configureSecurity(configFile, securityConfigFile, activationComment):
    try:
        SessionMBean = None
        print 'Loading Deployment config from :', configFile
        configProp = u.loadProps(configFile)
        adminUrl = configProp.get("adminUrl")
	print 
        importUser = configProp.get("importUser")
        importPassword = configProp.get("importPassword")
        target = configProp.get("target")
        targetCluster = configProp.get("targetCluster")
        domain = configProp.get("domain")
        connectToServer(importUser, importPassword, adminUrl)

        log('Attempting to configure security on Admin Server listening on :' + adminUrl)

        securityConfigProp = u.loadProps(securityConfigFile)
	countOfUsers = int(securityConfigProp.get('users'))
	countOfGroups = int(securityConfigProp.get('groups'))

	# Create / update groups first
	i=1
	while i<=countOfGroups:
		group=securityConfigProp.get('group.'+str(i)+'.name')
		description=securityConfigProp.get('group.'+str(i)+'.description')
		createGroup(group,description)
		i+=1

	i=1
	while i<=countOfUsers:
		username=securityConfigProp.get('user.'+str(i)+'.username')
		password=securityConfigProp.get('user.'+str(i)+'.password')
		description=securityConfigProp.get('user.'+str(i)+'.description')
		groups=securityConfigProp.get('user.'+str(i)+'.groups')
		createUser(username,password,description)
		## Add user to groups
		if groups!='':
			for g in groups.split(','):
				addUserToGroup(username,g)
		i+=1
	# Creating groups first


	#edit()
	#startEdit()
	## 
	## Resources to create or modify
	##
	##
	#save()
	#activate(block="true")
	#disconnect('true')
    except:
        print "Unexpected error:", sys.exc_info()[0]	
	disconnect('true')
        raise

# IMPORT script init
try:
    # import the service bus configuration
    # argv[1] is the export config properties file
    # argv[2] is the config file with username, password and group settings
    # argv[3] is the comment on activation
    # argv[4] is the python directory, in order to enable modules loading
    sys.path.append(sys.argv[4]+'/modules')
    from common import util
    u=util.Util()

    configureSecurity(sys.argv[1],sys.argv[2],sys.argv[3])

except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise
