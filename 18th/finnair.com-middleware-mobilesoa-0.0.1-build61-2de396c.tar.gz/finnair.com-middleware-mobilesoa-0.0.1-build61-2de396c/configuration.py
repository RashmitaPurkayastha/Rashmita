# Examples:
# List logging statuses for proxy services under MobileSOA path 
# ./logging.sh dev -pp MobileSOA/*

# Set MobileSOA/Airport/proxyservices/Airport.proxy logging level to INFo and enable message tracing at level "Headers"
# ./logging.sh dev -pp MobileSOA/Airport/proxyservices -pn Airport -pl INFO -pt true -ptl Headers

# Set logging level to INFO to all proxy services in MoblieSOA path and disable message tracing.
# ./logging.sh dev -pp MobileSOA/* -pl INFO -pt false

import sys , traceback
import xml.dom.minidom

from time import sleep
from com.bea.wli.sb.management.configuration import SessionManagementMBean
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.sb.management.configuration import ServiceConfigurationMBean
from com.bea.wli.sb.management.configuration import CommonServiceConfiguration
from com.bea.wli.sb.management.configuration.operations import LogSeverityLevel
from com.bea.wli.sb.management.configuration.operations import PipelineMonitoringLevel
from com.bea.wli.sb.management.configuration.operations import AlertSeverityLevel
from com.bea.wli.sb.management.query import ProxyServiceQuery
from com.bea.wli.sb.management.query import BusinessServiceQuery
from com.bea.wli.sb.management.query import ServiceQuery
from com.bea.wli.config import Ref
from com.bea.alsb.flow.management.configuration import FlowConfigurationMBean
from com.bea.alsb.flow.resources.config import LogLevels
from com.bea.wli.sb.util import Refs
from xml.dom.minidom import Node
from com.bea.wli.monitoring import ResourceType
from com.bea.wli.monitoring import ServiceResourceStatistic
from com.bea.wli.monitoring import StatisticValue
from com.bea.wli.monitoring import StatisticType

def setProxyLogLevel(serviceRef, proxyLogLevel):
    prxName = serviceRef.getFullName()
    if len(proxyLogLevel) > 0:
        if (proxyLogLevel == "NONE"):
            enabled = false
            str = "Disabled"
        else:
            enabled = true
            str = "Enabled"

        objs = jarray.array([serviceRef, java.lang.Boolean(enabled)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
        invoke("setServiceLoggingEnabled",objs, strs)
        print prxName + ' ' + str + ' logging'
    
    if len(proxyLogLevel) > 0 and proxyLogLevel != "NONE":
        objs = jarray.array([serviceRef, LogSeverityLevel.valueOf(proxyLogLevel)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','com.bea.wli.sb.management.configuration.operations.LogSeverityLevel'], java.lang.String )
        invoke("setServiceLogLevel",objs, strs)
        print prxName + ' Logging level set to '+proxyLogLevel

def setFlowLogLevel(operationsType, flowOperation, logLevel):
    commitneeded = false
    if len(logLevel) > 0:
        if (logLevel.lower() == "none"):
            newState = false
        else:
            newState = true

    if (operationsType):
        if len(logLevel) > 0:
            logLevel = logLevel.lower()
        newLogLevel = LogLevels.Enum.forString(logLevel)
        oldLogLevel = operationsType.getLogging().getLevel()
        oldState = operationsType.getLogging().getIsEnabled()
    
        if (oldState != newState):
            operationsType.getLogging().setIsEnabled(newState)
            commitneeded = true
    
        if (newState and oldLogLevel != newLogLevel):
            operationsType.getLogging().setLevel(newLogLevel)
            commitneeded = true
        return commitneeded
    else:
        newLogLevel = LogSeverityLevel.valueOf(logLevel)
        oldLogLevel = flowOperation.getLogLevel()
        oldState = flowOperation.isLoggingEnabled
    
        if (oldState != newState):
            flowOperation.setLoggingEnabled(newState)
            commitneeded = true
    
        if (newState and oldLogLevel != newLogLevel):
            flowOperation.setLogLevel(newLogLevel)
            commitneeded = true
        return commitneeded

# MonitoringLevel=DISABLE|Service|Action|Pipeline
def setMonitoringLevel(serviceRef, monitoringLevel, adjustLevel):
    prxName = serviceRef.getFullName()

    if len(monitoringLevel) > 0:
        if monitoringLevel=='DISABLE':
            objs = jarray.array([serviceRef, java.lang.Boolean(false)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
            invoke("setServiceMonitoringEnabled",objs, strs)
            print prxName + ' Disabled Monitoring'            
        else:
            objs = jarray.array([serviceRef, java.lang.Boolean(true)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
            invoke("setServiceMonitoringEnabled",objs, strs)
            print prxName + ' Enabled Monitoring'

        if (adjustLevel):
            objs = jarray.array([serviceRef, PipelineMonitoringLevel.valueOf(monitoringLevel)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','com.bea.wli.sb.management.configuration.operations.PipelineMonitoringLevel'], java.lang.String )
            invoke("setServicePipelineMonitoringLevel",objs, strs)
            print prxName + ' Monitoring level set to '+monitoringLevel

def getText(node):
    rc = ""
    for node in node.childNodes:
        if node.nodeType == node.TEXT_NODE:
            rc = rc + node.data
            return rc

def setBizLevels(refs, proxyLogLevel, proxyTracing, proxyTracingLevel):
  for serviceRef in refs:
    name = serviceRef.getFullName()
    if len(proxyTracing) > 0:
        objs = jarray.array([serviceRef, java.lang.Boolean(proxyTracing)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
        invoke("setMessageTracingEnabled",objs, strs)
        print name + ' tracing set to ' + proxyTracing 

    if len(proxyTracingLevel) > 0:
        objs = jarray.array([serviceRef, proxyTracingLevel],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','java.lang.String'], java.lang.String )
        invoke("setMessageTracingLevel",objs, strs)
        print name + ' Tracing level set to '+proxyTracingLevel

def setThrottlingLevel(serviceRef, ThrottlingEnable, ThrottlingTimeToLive, ThrottlingMaxQueueLength, ThrottlingMaxConcurrency):
    result = false

    bizName = serviceRef.getFullName()
    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    oldTimeToLive = str(invoke("getServiceThrottlingTimeToLive",objs, strs))
    oldMaxQueueLength = str(invoke("getServiceThrottlingMaxQueueLength",objs, strs))
    oldMaxConcurrency = str(invoke("getServiceThrottlingMaxConcurrency",objs, strs))
    oldState = str(invoke("isServiceThrottlingEnabled",objs, strs))
    if (oldState == 0):
        oldState = "false"
    elif (oldState == 1):
        oldState = "true"

    
    if oldState != ThrottlingEnable:
        objs = jarray.array([serviceRef, java.lang.Boolean(ThrottlingEnable)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
        invoke("setServiceThrottlingEnabled",objs, strs)
        print bizName + ' Throttling='+ThrottlingEnable
        result = true

    if oldTimeToLive != ThrottlingTimeToLive:
        objs = jarray.array([serviceRef, java.lang.Long(ThrottlingTimeToLive)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','long'], java.lang.String )
        invoke("setServiceThrottlingTimeToLive",objs, strs)
        print bizName + ' ThrottlingTimeToLive='+ThrottlingTimeToLive
        result = true

    if oldMaxQueueLength != ThrottlingMaxQueueLength:
        objs = jarray.array([serviceRef, java.lang.Integer(ThrottlingMaxQueueLength)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','int'], java.lang.String )
        invoke("setServiceThrottlingMaxQueueLength",objs, strs)
        print bizName + ' ThrottlingMaxQueueLength='+ThrottlingMaxQueueLength
        result = true

    if oldMaxConcurrency != ThrottlingMaxConcurrency:
        objs = jarray.array([serviceRef, java.lang.Long(ThrottlingMaxConcurrency)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','long'], java.lang.String )
        invoke("setServiceThrottlingMaxConcurrency",objs, strs)
        print bizName + ' ThrottlingMaxConcurrency='+ThrottlingMaxConcurrency
        result = true

def getMatchingEnv(serviceNode, tagName):
    for elem in serviceNode.getElementsByTagName(tagName):
        env = elem.getAttribute("env")
        if (env == environment):
            return env
    return ""
    
def doLogging(serviceNode, serviceRef):
    targetEnv = getMatchingEnv(serviceNode, "logging")
    for logging in serviceNode.getElementsByTagName("logging"):
        env = logging.getAttribute("env")
        if (env == targetEnv):
            setProxyLogLevel(serviceRef, logging.getAttribute("level"))
            found = true

    return true

def doMonitoring(serviceNode, serviceRef, adjustLevel):
    for monitoring in serviceNode.getElementsByTagName("monitoring"):
        value = getText(monitoring)
        setMonitoringLevel(serviceRef, value, adjustLevel)
    return true

def doThrottling(serviceNode, serviceRef):
    for throttling in serviceNode.getElementsByTagName("throttling"):
        throttlingEnable = throttling.getAttribute("enable")
        throttlingTimeToLive = throttling.getAttribute("ttl")
        throttlingMaxQueueLength = throttling.getAttribute("tmq")
        throttlingMaxConcurrency = throttling.getAttribute("tmc")
        setThrottlingLevel(serviceRef, throttlingEnable, throttlingTimeToLive, throttlingMaxQueueLength, throttlingMaxConcurrency)
    return true

def doFlowChanges(sj, ref):
    # Read operationsType
    objs = jarray.array([ref],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    flowInfo = invoke("getFlowInfo",objs, strs)
    
    operationsType = flowInfo.getOperations()
    
    flowOperation = invoke("getFlowOperation",objs, strs)
    flowOperation.setLogLevel(LogSeverityLevel.valueOf("ERROR"))

    flowCommitNeeded = false
    targetEnv = getMatchingEnv(sj, "logging")
    for logging in sj.getElementsByTagName("logging"):
        env = logging.getAttribute("env")
        if (env == targetEnv):
            flowCommitNeeded = setFlowLogLevel(operationsType, flowOperation, logging.getAttribute("level")) or commitNeeded

    # Update operationsType
    if (flowCommitNeeded):
        if (operationsType):
            objs = jarray.array([ref, operationsType],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref', 'com.bea.alsb.flow.resources.config.OperationsType'], java.lang.String )
            invoke("updateFlowOperation",objs, strs)
        else:
            theMap = java.util.HashMap()
            theMap.put(ref, flowOperation)
            objs = jarray.array([theMap],  java.lang.Object)
            strs = jarray.array(['java.util.Map'], java.lang.String )
            invoke("updateFlowOperations",objs, strs)
            
    return flowCommitNeeded
        

def doSLA(serviceNode, serviceRef):
    for slaNode in serviceNode.getElementsByTagName("sla"):
        return setSLALevel(serviceRef, slaNode.getAttribute("level")) 
    return false

# SLA level=NORMAL, WARNING, MINOR, MAJOR, CRITICAL, FATAL, NONE (custom value for disabling)
def setSLALevel(serviceRef, level):
    slaModified = false
    name = serviceRef.getFullName()
    if len(level) > 0:
        if (level == "NONE"):
            newState = false
            str = "Disabled"
        else:
            newState = true
            str = "Enabled"

        objs = jarray.array([serviceRef],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
        oldState = invoke("isServiceSLAAlertingEnabled",objs, strs)
        if (oldState == 1):
            oldState = true
        else:
            oldState = false
        
        if (oldState != newState):
            objs = jarray.array([serviceRef, java.lang.Boolean(newState)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
            invoke("setServiceSLAAlertingEnabled",objs, strs)
            print name + ' ' + str + ' SLA Alerting'
            slaModified = true
    
        objs = jarray.array([serviceRef],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
        oldLevel = invoke("getServiceSLAAlertLevel",objs, strs)

        if len(level) > 0 and level != "NONE":
            newLevel = AlertSeverityLevel.valueOf(level)
            if (oldLevel.toString() != newLevel.toString()):
                objs = jarray.array([serviceRef, newLevel],  java.lang.Object)
                strs = jarray.array(['com.bea.wli.config.Ref','com.bea.wli.sb.management.configuration.operations.AlertSeverityLevel'], java.lang.String )
                invoke("setServiceSLAAlertLevel",objs, strs)
                print name + ' SLA ALert level set to '+level
                slaModified = true
    return slaModified

def getArg(argv, idx):
 if idx < len(sys.argv):
   return sys.argv[idx]
 else:
   return ""

print ''
if len(sys.argv) < 3:
 print "Invalid number of arguments."
 exit()
environment=sys.argv[1]
propertiesFile=sys.argv[2]
configurationFile=sys.argv[3]

loadProperties(propertiesFile)

dom = xml.dom.minidom.parse(configurationFile)
proxies = dom.getElementsByTagName("proxyService")
bizes = dom.getElementsByTagName("businessService")
splitJoins = dom.getElementsByTagName("splitJoin")

connect(importUser, importPassword, adminUrl)
domainRuntime()
cd('domainRuntime:/DomainServices/ServiceDomain')


# Sample code for dumping statistics
#for proxy in proxies:
#  path = proxy.getAttribute("path")
#  ref = Ref("ProxyService", path.split("/"))
#  props = cmo.getProxyServiceStatistics([ref],ResourceType.SERVICE.value(), '')
#  for rs in props[ref].getAllResourceStatistics():
#            for e in rs.getStatistics():
#                    if e.getType() == StatisticType.COUNT:
#                        print e.getName() + "("+ str(e.getType()) +"): " + str(e.getCount())
#                    if e.getType() == StatisticType.INTERVAL:
#                        print e.getName() + "("+ str(e.getType()) +"): " + str(e.getMin()) + " " + str(e.getMax()) + " " + str(e.getAverage()) + " " + str(e.getSum())
#                    if e.getType() == StatisticType.STATUS:
#                        print e.getName() + "("+ str(e.getType()) +"): " + str(e.getCurrentStatus()) + "(" + str(e.getInitialStatus()) + ")"



alsbCore = findService(ALSBConfigurationMBean.NAME, ALSBConfigurationMBean.TYPE)

try:
  print "CGI:Creating session"
  sessionName  = "ChangeLogLevelsSession" + str(System.currentTimeMillis())
  sessionMBean = findService(SessionManagementMBean.NAME, SessionManagementMBean.TYPE)
  sessionMBean.createSession(sessionName)


  print "CGI:Changing to custom domain"
  domainCustom()

  cd ("com.bea")
  nomServiceConfigurationMBean = String("ServiceConfiguration.").concat(sessionName)
  cd ("com.bea:Name="+ nomServiceConfigurationMBean +",Location=AdminServer,Type=com.bea.wli.sb.management.configuration.ServiceConfigurationMBean")

  commitNeeded = false

  # Proxy services
  for proxy in proxies:
    path = proxy.getAttribute("path")
    print "Processing ProxyService " + path 
    ref = Ref("ProxyService", path.split("/"))
        
    commitNeeded = doLogging(proxy, ref) or commitNeeded
    commitNeeded = doMonitoring(proxy, ref, true) or commitNeeded
    commitNeeded = doSLA(proxy, ref) or commitNeeded

  # Business services
  for biz in bizes:
    path = biz.getAttribute("path")
    print "Processing BusinessService " + path 
    ref = Ref("BusinessService", path.split("/"))
    commitNeeded = doMonitoring(biz, ref, false) or commitNeeded
    commitNeeded = doThrottling(biz, ref) or commitNeeded

  # SplitJoins
  cd ("/")
  cd ("com.bea")
  nomFlowConfigurationMBean = String("FlowConfiguration.").concat(sessionName)
  cmo = cd ("com.bea:Name="+ nomFlowConfigurationMBean +",Location=AdminServer,Type=com.bea.alsb.flow.management.configuration.FlowConfigurationMBean")

  splitJoinMap = java.util.HashMap()
  for sj in splitJoins:
    path = sj.getAttribute("path")
    print "Processing SplitJoin " + path 
    ref = Ref("FLOW", path.split("/"))
    commitNeeded = doFlowChanges(sj, ref) or commitNeeded

  # Commit changes
  if commitNeeded:
    print "CGI:Activating session"
    sessionMBean.activateSession(sessionName,'Changing log levels.')
  else:
    sessionMBean.discardSession(sessionName)
except:
  sessionMBean.discardSession(sessionName)
  print 'Got Error'
  apply(traceback.print_exception, sys.exc_info())
  dumpStack()    

print 'Finished.'
