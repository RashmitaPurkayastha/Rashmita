#!/bin/sh

## Get the absolutepath to installation directory
INSTALLDIR=$(cd $(dirname "$0") && pwd -P)
DATE=`date +%Y_%m_%d_%H\:%M\:%S`
LOGFILE="OSB_install_${DATE}.log"
STATUSFILE=$INSTALLDIR/status
ENV=$1

function usage {
	echo "Usage: ./`basename $0` <dev|preprod|proda|prodb> [full path to Services.xml]";
	exit
}


COUNT=$#
# Check that enough parameters are given
if [ $COUNT -lt 2 ]; then
	usage;
fi

IDX=0
i=2
while [ $i -le $COUNT ]; do
    eval ARGS[$IDX]=\${$i}
    IDX=$((IDX + 1))
    i=$((i+1))
done

# Check first environment
case "$ENV" in 
dev)
MW_HOME=/home/Oracle/Middleware
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/Oracle_OSB1
;;
preprod)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
proda)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
prodb)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
*)
usage
;;
esac



function log {
	echo `date +"%d.%m.%Y %H:%M:%S": ` "$@"
}

rm $STATUSFILE

{
	log Starting installation
	WLST=$MW_HOME/wlserver_10.3/common/bin/wlst.sh
	log WLST started from: $WLST
	#Set domain env
	. $DOMAIN_HOME/bin/setDomainEnv.sh

	# Execute resource configuration file
	log Executing configuration to WLS
	echo ${ARGS[*]}
	$WLST $INSTALLDIR/configuration.py ${ENV} $INSTALLDIR/env/${ENV}.properties ${ARGS[*]} 2>&1 || echo $? > $STATUSFILE
	if [ -f $STATUSFILE ]; then
		log Failed
		exit $CODE;
	fi
	log Finished

} 2>&1 | tee $LOGFILE
if [ -f $STATUSFILE ]; then
	CODE=`cat $STATUSFILE`;
	#rm $STATUSFILE;
	log Installation failed with error code=$CODE
	exit $CODE;
fi
