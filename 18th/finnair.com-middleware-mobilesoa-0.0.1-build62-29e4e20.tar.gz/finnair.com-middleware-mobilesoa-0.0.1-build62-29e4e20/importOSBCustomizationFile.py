from java.util import HashMap
from java.util import HashSet
from java.util import ArrayList
from java.io import FileInputStream

from com.bea.wli.sb.util import Refs
from com.bea.wli.config.customization import Customization
from com.bea.wli.sb.management.importexport import ALSBImportOperation

import sys

#====================================================================
# Entry function to deploy project configuration and resources
#        into a ALSB domain
#====================================================================

def importToALSBDomain(importConfigFile, customFile, comment):
    try:
	redirect('/dev/null', 'true')
        SessionMBean = None
        print 'Loading Deployment config from :', importConfigFile
        exportConfigProp = loadProps(importConfigFile)
        adminUrl = exportConfigProp.get("adminUrl")
        importUser = exportConfigProp.get("importUser")
        importPassword = exportConfigProp.get("importPassword")

#        importJar = exportConfigProp.get("importJar")
#        customFile = exportConfigProp.get("customizationFile")
	print 'A customization file specified: ', customFile

        passphrase = exportConfigProp.get("passphrase")
#        project = exportConfigProp.get("project")

        connectToServer(importUser, importPassword, adminUrl)

#        print 'Attempting to import :', importJar, "on ALSB Admin Server listening on :", adminUrl

        sessionName = createSessionName()
        print 'Created session', sessionName
        SessionMBean = getSessionManagementMBean(sessionName)
        print 'SessionMBean started session'
        ALSBConfigurationMBean = findService(String("ALSBConfiguration.").concat(sessionName), "com.bea.wli.sb.management.configuration.ALSBConfigurationMBean")
        print "ALSBConfiguration MBean found", ALSBConfigurationMBean

        #customize if a customization file is specified
        #affects only the created resources
        if customFile != None :
		print 'Loading customization File', customFile
		#print 'Customization applied to the created resources only', createdRef
		iStream = FileInputStream(customFile)
		customizationList = Customization.fromXML(iStream)
	#                filteredCustomizationList = ArrayList()
	#                setRef = HashSet(createdRef)

		# apply a filter to all the customizations to narrow the target to the created resources
	#                for customization in customizationList:
	#                    print customization
	#                    newcustomization = customization.clone(setRef)
	#                    filteredCustomizationList.add(newcustomization)

		ALSBConfigurationMBean.customize(customizationList)
	else :
		print "No customization file was given"
		raise

        SessionMBean.activateSession(sessionName, "Customization file import: " + comment)

        print "Execution of : " + customFile + " successful"
    except:
        print "Unexpected error:", sys.exc_info()[0]
        if SessionMBean != None:
            SessionMBean.discardSession(sessionName)
        raise

#===================================================================
# Utility function to print the list of operations
#===================================================================
def printOpMap(map):
    set = map.entrySet()
    for entry in set:
        op = entry.getValue()
        print op.getOperation(),
        ref = entry.getKey()
        print ref
    print

#===================================================================
# Utility function to print the diagnostics
#===================================================================
def printDiagMap(map):
    set = map.entrySet()
    for entry in set:
        diag = entry.getValue().toString()
        print diag
    print

#===================================================================
# Utility function to load properties from a config file
#===================================================================

def loadProps(configPropFile):
    propInputStream = FileInputStream(configPropFile)
    configProps = Properties()
    configProps.load(propInputStream)
    return configProps

#===================================================================
# Connect to the Admin Server
#===================================================================

def connectToServer(username, password, url):
    connect(username, password, url)
    domainRuntime()

#===================================================================
# Utility function to read a binary file
#===================================================================
def readBinaryFile(fileName):
    file = open(fileName, 'rb')
    bytes = file.read()
    return bytes

#===================================================================
# Utility function to create an arbitrary session name
#===================================================================
def createSessionName():
    sessionName = String("SessionScript"+Long(System.currentTimeMillis()).toString())
    return sessionName

#===================================================================
# Utility function to load a session MBeans
#===================================================================
def getSessionManagementMBean(sessionName):
    SessionMBean = findService("SessionManagement", "com.bea.wli.sb.management.configuration.SessionManagementMBean")
    SessionMBean.createSession(sessionName)
    return SessionMBean


# IMPORT script init
try:
    # import the service bus configuration
    # argv[1] is the export config properties file
    # argv[2] is the customization file
    # argv[2] is the activation comment
    importToALSBDomain(sys.argv[1],sys.argv[2],sys.argv[3])

except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise
