from java.util import HashMap
from java.util import HashSet
from java.util import ArrayList
from java.io import FileInputStream

#===================================================================
# Utility function to create a JDBC data source
#  name = name of ds to create
#  user = user to use for connecting to ds
#  pwd  = credential to access
#  hostname = DB server hostname
#  port = DB port
#  dbname = SSID of db to connect to
#===================================================================
def createJDBCDataSource(name,user,pw,hostname,port,dbname):
	log('Creating a datasource: ' + name)
	cmo.createJDBCSystemResource(name)
	# Create a new Mbean ( a JDBC resource)
	
	#Naming the datasource
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name)
	cmo.setName(name)
	#Setting JNDI name
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCDataSourceParams/'+name)
	set('JNDINames',jarray.array([String(name)], String))
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCDriverParams/'+name)
	cmo.setUrl('jdbc:oracle:thin:@'+hostname+':'+port+':'+dbname)
	cmo.setDriverName('oracle.jdbc.OracleDriver')
	cmo.setPassword(pw)

	#Set Connection Pool specific parameters
	# refer: e-docs.bea.com/wls/docs92/wlsmbeanref/mbeans/JDBCConnectionPoolParamsBean.html
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCConnectionPoolParams/'+name)
	cmo.setTestConnectionsOnReserve(true)
	cmo.setTestTableName('SQL SELECT 1 FROM DUAL')
	cmo.setConnectionReserveTimeoutSeconds(10)
	cmo.setMaxCapacity(15)
	cmo.setConnectionReserveTimeoutSeconds(10)
	cmo.setTestFrequencySeconds(120)

	# Setting the user name
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCDriverParams/'+name+'/Properties/'+name)
	cmo.createProperty('user')
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCDriverParams/'+name+'/Properties/'+name+'/Properties/user')
	cmo.setValue(user)

	# Setting the database name
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCDriverParams/'+name+'/Properties/'+name)
	cmo.createProperty('databaseName')
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCDriverParams/'+name+'/Properties/'+name+'/Properties/databaseName')
	cmo.setValue('jdbc:oracle:thin:@'+hostname+':'+port+':'+dbname)

	# Transaction
	cd('/JDBCSystemResources/'+name+'/JDBCResource/'+name+'/JDBCDataSourceParams/'+name)
	cmo.setGlobalTransactionsProtocol('OnePhaseCommit')
	cd('/JDBCSystemResources/'+name)
	# targets the DS1 to Servers(AdminServer,MS)
	set('Targets',jarray.array([ObjectName('com.bea:Name=AdminServer,Type=Server')], ObjectName))
	
	return

def createDestinationKey(jmsmodule, name):
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule+'/DestinationKeys')
	cmo.createDestinationKey(name)
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule+'/DestinationKeys/'+name)
	set('KeyType','Int')
	set('Name',name)
	set('Property','JMSPriority')
	set('SortOrder','Ascending')
	
def createQueue(name,jndi,subdep,destkey,jmsmodule):
	log('Creating Queue: ' + name)	
	cd('/')
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule)
	cmo.createQueue(name)
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule+'/Queues/'+name)
	set('JNDIName',jndi)
	set('SubDeploymentName',subdep)
	cmo.addDestinationKey(destkey)	
	#cd('/JMSSystemResources/jmsResources/SubDeployments/wlsbJMSServer')
	#cmo.addTarget(getMBean('/JMSServers/JMSServer0'))
	
def createUniformDistributedQueue(jmsmodule,name,jndi,destkey):
	log('Creating Uniform Distributed Queue: ' + name)
	cd('/')
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule)
	cmo.createUniformDistributedQueue(name)
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule+'/UniformDistributedQueues/'+name)
	set('JNDIName',jndi)
	#set('DefaultTargetingEnabled',"true")
	set('SubDeploymentName','wlsbJMSServer_auto')
	cmo.addDestinationKey(destkey)	
		
def createUniformDistributedTopic(jmsmodule,name,jndi):
	log('Creating Uniform Distributed Topic: ' + name)
	log('  with jndi: ' + jndi);
	cd('/')
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule)
	cmo.createUniformDistributedTopic(name)
	cd('/JMSSystemResources/'+jmsmodule+'/JMSResource/'+jmsmodule+'/UniformDistributedTopics/'+name)
	set('JNDIName',jndi)
	#set('DefaultTargetingEnabled',"true")
	set('SubDeploymentName','wlsbJMSServer_auto')
	#cmo.addDestinationKey(destkey)	

def createJMSModule(name):
	log('JMS Module: ' + name)
	log('Target: ' + target)	
	cd('/JMSSystemResources')
	cmo.createJMSSystemResource(name)
	# Add target
	cd('/JMSSystemResources/'+name+'/Targets')
	if targetCluster == "":
		cmo.addTarget(getMBean('/Servers/'+target))
	else:	
		cmo.addTarget(getMBean('/Clusters/'+targetCluster))
		
	# Subdeployment:
	cmo.createSubDeployment('wlsbJMSServer_auto')
	cd('/JMSSystemResources/'+name+'/SubDeployments/wlsbJMSServer_auto')
	if targetCluster == "":
		cmo.addTarget(getMBean('/JMSServers/wlsbJMSServer'))	
	else:		
		cmo.addTarget(getMBean('/JMSServers/wlsbJMSServer_auto_1'))	
		cmo.addTarget(getMBean('/JMSServers/wlsbJMSServer_auto_2'))

#
# Work manager related functions
#
#===================================================================
# Utility function to create a Fair Share Request Class
#   name = Fair Share request class name
#   fairshare = numeric value of Fair share to allocate
#===================================================================
def createFairShareRequestClass(name,fairshare,domain,target,targetCluster):
        log('Starting to configure FairShare Request Class: '+name)
	try:
		cd('/SelfTuning/'+domain+'/FairShareRequestClasses/'+name)
	except:
	        log('FairShare Request Class: '+name+' does not exist. Starting to create..')
		cd('/SelfTuning/'+domain+'/FairShareRequestClasses/')
		create(name,'FairShareRequestClass')
		cd(name)
	set('FairShare',fairshare)
	if targetCluster == "":
		cmo.addTarget(getMBean('/Servers/'+target))
	else:	
		cmo.addTarget(getMBean('/Clusters/'+targetCluster))
		
#
# Work manager related functions
#
#===================================================================
# Utility function to create a MaxThreads Constraint
#   name = Max Threads Constraint name
#   maxthreads = numeric value of Maximum threads to allocate
#===================================================================
def createMaxThreadsConstraint(name,maxthreads,domain,target,targetCluster):
        log('Starting to configure MaxThreadsConstraint: '+name)
	try:
		cd('/SelfTuning/'+domain+'/MaxThreadsConstraints/'+name)
	except:
	        log('MaxThreadsConstraint: '+name+' does not exist. Starting to create..')
		cd('/SelfTuning/'+domain+'/MaxThreadsConstraints/')
		create(name,'MaxThreadsConstraint')
		cd(name)
	set('Count',maxthreads)
	if targetCluster == "":
		cmo.addTarget(getMBean('/Servers/'+target))
	else:	
		cmo.addTarget(getMBean('/Clusters/'+targetCluster))

#===================================================================
# Utility function to create a Work Manager
#   name = Work Manager name
#===================================================================
def createWorkManager(name,domain,target,targetCluster):
        log('Starting to configure WorkManager: '+name)
	try:
		cd('/SelfTuning/'+domain+'/WorkManagers/'+name)
	except:
	        log('WorkManager ('+name+') does not exist. Starting to create...)')
		cd('/SelfTuning/'+domain+'/WorkManagers')
		create(name,'WorkManager')
		cd(name)
	if targetCluster == "":
		cmo.addTarget(getMBean('/Servers/'+target))
	else:	
		cmo.addTarget(getMBean('/Clusters/'+targetCluster))

#===================================================================
# Utility function to assign a FairShareReqestClass to a Work Manager
#   workmanager = Work Manager name
#   name = Fair Share request class name
#===================================================================
def attachFairShareRequestClass(workmanager,name,domain):
	cd('/SelfTuning/'+domain+'/WorkManagers/'+workmanager)
	set('FairShareRequestClass',getMBean('/SelfTuning/'+domain+'/FairShareRequestClasses/'+name))
	
#===================================================================
# Utility function to assign a MaxThreadsConstraint to a Work Manager
#   workmanager = Work Manager name
#   name = MaxThreadsConstraint name
#===================================================================
def attachMaxThreadsConstraint(workmanager,name,domain):
	cd('/SelfTuning/'+domain+'/WorkManagers/'+workmanager)
	set('MaxThreadsConstraint',getMBean('/SelfTuning/'+domain+'/MaxThreadsConstraints/'+name))

def log(string):	
    print '   --> ' + string
	
#===================================================================
# Utility function to print the list of operations
#===================================================================
def printOpMap(map):
    set = map.entrySet()
    for entry in set:
        op = entry.getValue()
        print op.getOperation(),
        ref = entry.getKey()
        print ref
    print

#===================================================================
# Utility function to print the diagnostics
#===================================================================
def printDiagMap(map):
    set = map.entrySet()
    for entry in set:
        diag = entry.getValue().toString()
        print diag
    print

#===================================================================
# Utility function to load properties from a config file
#===================================================================

def loadProps(configPropFile):
    propInputStream = FileInputStream(configPropFile)
    configProps = Properties()
    configProps.load(propInputStream)
    return configProps

#===================================================================
# Connect to the Admin Server
#===================================================================

def connectToServer(username, password, url):
    connect(username, password, url)
    domainRuntime()

#===================================================================
# Utility function to read a binary file
#===================================================================
def readBinaryFile(fileName):
    file = open(fileName, 'rb')
    bytes = file.read()
    return bytes

#===================================================================
# Utility function to create an arbitrary session name
#===================================================================
def createSessionName():
    sessionName = String("SessionScript"+Long(System.currentTimeMillis()).toString())
    return sessionName

#===================================================================
# Utility function to load a session MBeans
#===================================================================
def getSessionManagementMBean(sessionName):
    SessionMBean = findService("SessionManagement", "com.bea.wli.sb.management.configuration.SessionManagementMBean")
    SessionMBean.createSession(sessionName)
    return SessionMBean

#====================================================================
# Entry function to configure project configuration and resources
#        into a domain
#====================================================================

def configureResources(importConfigFile, activationComment):
    try:
        SessionMBean = None
        print 'Loading Deployment config from :', importConfigFile
        exportConfigProp = loadProps(importConfigFile)
        adminUrl = exportConfigProp.get("adminUrl")
        importUser = exportConfigProp.get("importUser")
        importPassword = exportConfigProp.get("importPassword")
        target = exportConfigProp.get("target")
        targetCluster = exportConfigProp.get("targetCluster")
        domain = exportConfigProp.get("domain")

        connectToServer(importUser, importPassword, adminUrl)

        log('Attempting to configure resources on Admin Server listening on :' + adminUrl)

	edit()
	startEdit()
	## 
	## Resources to create or modify
	##
	#Create fair share request classes
	createFairShareRequestClass('Finnair-share-200',200,domain,target,targetCluster)
	createFairShareRequestClass('Finnair-share-100',100,domain,target,targetCluster)
	createFairShareRequestClass('Finnair-share-50',50,domain,target,targetCluster)
	createFairShareRequestClass('Finnair-share-25',25,domain,target,targetCluster)
	createFairShareRequestClass('Finnair-share-10',10,domain,target,targetCluster)
	createFairShareRequestClass('Finnair-share-5',5,domain,target,targetCluster)
	#Create MaxThreadsConstraints
	createMaxThreadsConstraint('Finnair-MaxThreads-AmadeusWrapper',20,domain,target,targetCluster)
	# AYOnline_Critical
	createWorkManager('AYOnline_Critical',domain,target,targetCluster)
	attachFairShareRequestClass('AYOnline_Critical','Finnair-share-200',domain) 
	# AYOnline_High
	createWorkManager('AYOnline_High',domain,target,targetCluster)
	attachFairShareRequestClass('AYOnline_High','Finnair-share-100',domain) 
	# AYOnline_Medium
	createWorkManager('AYOnline_Medium',domain,target,targetCluster)
	attachFairShareRequestClass('AYOnline_Medium','Finnair-share-50',domain) 
	# AYOnline_Low
	createWorkManager('AYOnline_Low',domain,target,targetCluster)
	attachFairShareRequestClass('AYOnline_Low','Finnair-share-25',domain) 
	# AYOffline
	createWorkManager('AYOffline',domain,target,targetCluster)
	attachFairShareRequestClass('AYOffline','Finnair-share-10',domain) 
	# Partners_Online_Critical
	createWorkManager('Partners_Online_Critical',domain,target,targetCluster)
	attachFairShareRequestClass('Partners_Online_Critical','Finnair-share-100',domain) 
	# Partners_Online_Regular
	createWorkManager('Partners_Online_Regular',domain,target,targetCluster)
	attachFairShareRequestClass('Partners_Online_Regular','Finnair-share-50',domain) 
	# Partners_Offline
	createWorkManager('Partners_Offline',domain,target,targetCluster)
	attachFairShareRequestClass('Partners_Offline','Finnair-share-5',domain) 
	# AmadeusWrapper constraint
	createWorkManager('AmadeusWrapper_WorkManager',domain,target,targetCluster)
	attachMaxThreadsConstraint('AmadeusWrapper_WorkManager','Finnair-MaxThreads-AmadeusWrapper',domain) 
	##
	save()
	activate(block="true")
	disconnect('true')
    except:
        print "Unexpected error:", sys.exc_info()[0]	
	disconnect('true')
        raise

# IMPORT script init
try:
    # import the service bus configuration
    # argv[1] is the export config properties file
    # argv[2] is the comment on activation
    configureResources(sys.argv[1],sys.argv[2])

except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise
