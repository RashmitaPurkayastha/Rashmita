# Examples:
# List monitoring levels for proxy and business services under MobileSOA path 
# ./monitoring.sh dev -pp MobileSOA/*

# Set MobileSOA/Airport/proxyservices/Airport.proxy monitoring level to Action level and enable monitoring on business services 
# ./logging.sh dev -pp MobileSOA/Airport/proxyservices -pn Airport -pl Action

# Disable monitoring on all proxy and business services in MobileSOA path.
# ./logging.sh dev -pp MobileSOA/* -pl DISABLE

import sys , traceback
from time import sleep
from com.bea.wli.sb.management.configuration import SessionManagementMBean
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.sb.management.configuration import ServiceConfigurationMBean
from com.bea.wli.sb.management.configuration.operations import LogSeverityLevel
from com.bea.wli.sb.management.configuration.operations import PipelineMonitoringLevel
from com.bea.wli.sb.management.query import ProxyServiceQuery
from com.bea.wli.sb.management.query import BusinessServiceQuery
from com.bea.wli.config import Ref

#from com.bea.wli.monitoring import StatisticType
from com.bea.wli.sb.util import Refs

# Call this with proxyRefs=true in order to get only proxy refs
def getRefs(alsbCore, path, name,proxyRefs):
  if (proxyRefs):
      query = ProxyServiceQuery()
  else:
      query = BusinessServiceQuery()
  query.setPath(path)
  if len(name) > 0:
   query.setLocalName(name)
  else:
   query.setLocalName("*")
  refs=alsbCore.getRefs(query)
  return refs

def getProxyRefs(alsbCore, path, name):
  return getRefs(alsbCore,path,name,true)

def getBizRefs(alsbCore, path, name):
  return getRefs(alsbCore,path,name,false)

def listMonitoringLevels(proxyRefs,bizRefs):
  print ""
  print "CGI:Listing proxy levels"
  print "========================"
  for serviceRef in proxyRefs:
    print serviceRef.getClass().getName()
    prxName = serviceRef.getFullName()
    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    isMonitoringEnabled = str(invoke("isMonitoringEnabled",objs, strs))
    if (isMonitoringEnabled == 0):
        isMonitoringEnabled = "false"
    elif (isMonitoringEnabled == 1):
        isMonitoringEnabled = "true"

    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    monitoringLevel = str(invoke("getServicePipelineMonitoringLevel",objs, strs))

    print prxName.ljust(80)+(' monitoringEnabled: '+isMonitoringEnabled).ljust(16)+" monitoringLevel: "+monitoringLevel

  print ""
  print "CGI:Listing business service levels"
  print "==================================="
  for serviceRef in bizRefs:
    print serviceRef.toString()
    bizName = serviceRef.getFullName()
    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    isMonitoringEnabled = str(invoke("isMonitoringEnabled",objs, strs))
    if (isMonitoringEnabled == 0):
        isMonitoringEnabled = "false"
    elif (isMonitoringEnabled == 1):
        isMonitoringEnabled = "true"

    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    #monitoringLevel = str(invoke("isMonitoringEnabled",objs, strs))

    print bizName.ljust(80)+(' monitoringEnabled: '+isMonitoringEnabled).ljust(16)

# MonitoringLevel=DISABLE|Service|Action|Pipeline
def setMonitoringLevels(proxyRefs,bizRefs, monitoringLevel):
  for serviceRef in proxyRefs:
    prxName = serviceRef.getFullName()

    if len(monitoringLevel) > 0:
        if monitoringLevel=='DISABLE':
            objs = jarray.array([serviceRef, java.lang.Boolean(false)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
            invoke("setServiceMonitoringEnabled",objs, strs)
            print prxName + ' Disabled Monitoring'            
        else:
            objs = jarray.array([serviceRef, java.lang.Boolean(true)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
            invoke("setServiceMonitoringEnabled",objs, strs)
            print prxName + ' Enabled Monitoring'

            objs = jarray.array([serviceRef, PipelineMonitoringLevel.valueOf(monitoringLevel)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','com.bea.wli.sb.management.configuration.operations.PipelineMonitoringLevel'], java.lang.String )
            invoke("setServicePipelineMonitoringLevel",objs, strs)
            print prxName + ' Monitoring level set to '+monitoringLevel

  for serviceRef in bizRefs:
    bizName = serviceRef.getFullName()

    if len(monitoringLevel) > 0:
        if monitoringLevel=='DISABLE':
            objs = jarray.array([serviceRef, java.lang.Boolean(false)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
            invoke("setServiceMonitoringEnabled",objs, strs)
            print bizName + ' Disabled Monitoring'            
        else:
            objs = jarray.array([serviceRef, java.lang.Boolean(true)],  java.lang.Object)
            strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
            invoke("setServiceMonitoringEnabled",objs, strs)
            print bizName + ' Enabled Monitoring'

def getArg(argv, idx):
 if idx < len(sys.argv):
   return sys.argv[idx]
 else:
   return ""

print ''
if len(sys.argv) <= 2:
 print "Invalid number of arguments."
 print 'Usage: setMessageTracingStatus.py -pp <proxypath> -pn <proxyname> [-pl <monitoring level [DISABLE|Service|Action|Pipeline]> ]'
 exit()
propertiesFile=sys.argv[1]

proxyPath = ""
proxyName = "*"
monitoringLevel = ""
proxyTracing = ""
proxyTracingLevel = ""
idx = 2
while idx < len(sys.argv):
 a = sys.argv[idx]
 if a == "-pp":
     idx = idx + 1
     proxyPath = getArg(sys.argv, idx)
 elif a == "-pn":
     idx = idx + 1
     proxyName = getArg(sys.argv, idx)
 elif a == "-pl":
     idx = idx + 1
     monitoringLevel = getArg(sys.argv, idx)
 idx = idx + 1

print "proxyPath = "+proxyPath
print "proxyName = "+proxyName
print "monitoringLevel = "+monitoringLevel

loadProperties(propertiesFile)
connect(importUser, importPassword, adminUrl)
domainRuntime()

try:
  print "CGI:Creating session"
  sessionName  = "ChangeMonitoringLevelsSession" + str(System.currentTimeMillis())
  sessionMBean = findService(SessionManagementMBean.NAME, SessionManagementMBean.TYPE)
  sessionMBean.createSession(sessionName)

  alsbCore = findService(ALSBConfigurationMBean.NAME, ALSBConfigurationMBean.TYPE)
  
  if len(proxyPath) > 0:
    print "CGI:Finding proxy services"
    proxyRefs = getProxyRefs(alsbCore, proxyPath, proxyName)
    print "CGI:Finding business services"
    bizRefs = getBizRefs(alsbCore, proxyPath, proxyName)
  else:
    proxyRefs = []
    bizRefs = []

  print "CGI:Changing to custom domain"
  domainCustom()

  cd ("com.bea")
  nomServiceConfigurationMBean = String("ServiceConfiguration.").concat(sessionName)
  cd ("com.bea:Name="+ nomServiceConfigurationMBean +",Location=AdminServer,Type=com.bea.wli.sb.management.configuration.ServiceConfigurationMBean")

  hasmonitoringLevel = len(monitoringLevel)>0
  hasProxyRefs=false
  for i in proxyRefs:
    hasProxyRefs=true
    break

  commitNeeded = hasmonitoringLevel

  if (hasProxyRefs and not(hasmonitoringLevel)):
      listMonitoringLevels(proxyRefs,bizRefs)

  if (hasProxyRefs and hasmonitoringLevel):
      setMonitoringLevels(proxyRefs, bizRefs, monitoringLevel)
    
  if commitNeeded:
    print "CGI:Activating session"
    sessionMBean.activateSession(sessionName,'Changing monitoring levels.')
  else:
    sessionMBean.discardSession(sessionName)
except:
  sessionMBean.discardSession(sessionName)
  print 'Got Error'
  apply(traceback.print_exception, sys.exc_info())
  dumpStack()    



print 'Finished.'
