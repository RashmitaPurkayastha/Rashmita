from java.util import HashMap
from java.util import HashSet
from java.util import ArrayList
from java.util import Properties
from java.io import FileInputStream
#from com.bea.wli.sb.util import Refs
#from com.bea.wli.config.customization import Customization
#from com.bea.wli.sb.management.importexport import ALSBImportOperation

class Util(object):
	#===================================================================
	# Utility function to load properties from a config file
	#===================================================================

	def loadProps(self, configPropFile):
	    propInputStream = FileInputStream(configPropFile)
	    configProps = Properties()
	    configProps.load(propInputStream)
	    return configProps

	#===================================================================
	# Utility function to print the list of operations
	#===================================================================
	def printOpMap(map):
	    set = map.entrySet()
	    for entry in set:
		op = entry.getValue()
		print op.getOperation(),
		ref = entry.getKey()
		print ref
	    print

	#===================================================================
	# Utility function to print the diagnostics
	#===================================================================
	def printDiagMap(map):
	    set = map.entrySet()
	    for entry in set:
		diag = entry.getValue().toString()
		print diag
	    print

	#===================================================================
	# Utility function to read a binary file
	#===================================================================
	def readBinaryFile(fileName):
	    file = open(fileName, 'rb')
	    bytes = file.read()
	    return bytes

	#===================================================================
	# Utility function to create an arbitrary session name
	#===================================================================
	def createSessionName():
	    sessionName = String("SessionScript"+Long(System.currentTimeMillis()).toString())
	    return sessionName

	#===================================================================
	# Utility function to load a session MBeans
	#===================================================================
	def getSessionManagementMBean(sessionName):
	    SessionMBean = findService("SessionManagement", "com.bea.wli.sb.management.configuration.SessionManagementMBean")
	    SessionMBean.createSession(sessionName)
	    return SessionMBean
