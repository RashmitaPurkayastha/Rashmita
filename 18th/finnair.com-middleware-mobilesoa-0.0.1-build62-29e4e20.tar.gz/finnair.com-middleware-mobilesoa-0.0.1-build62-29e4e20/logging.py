# Examples:
# List logging statuses for proxy services under MobileSOA path 
# ./logging.sh dev -pp MobileSOA/*

# Set MobileSOA/Airport/proxyservices/Airport.proxy logging level to INFo and enable message tracing at level "Headers"
# ./logging.sh dev -pp MobileSOA/Airport/proxyservices -pn Airport -pl INFO -pt true -ptl Headers

# Set logging level to INFO to all proxy services in MoblieSOA path and disable message tracing.
# ./logging.sh dev -pp MobileSOA/* -pl INFO -pt false

import sys , traceback
from time import sleep
from com.bea.wli.sb.management.configuration import SessionManagementMBean
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.sb.management.configuration import ServiceConfigurationMBean
from com.bea.wli.sb.management.configuration.operations import LogSeverityLevel
from com.bea.wli.sb.management.query import ProxyServiceQuery
from com.bea.wli.sb.management.query import BusinessServiceQuery
from com.bea.wli.sb.management.query import ServiceQuery
from com.bea.wli.config import Ref

#from com.bea.wli.monitoring import StatisticType
from com.bea.wli.sb.util import Refs

# Call this with proxyRefs=true in order to get only proxy refs
def getRefs(alsbCore, path, name,proxyRefs):
  if (proxyRefs):
      query = ProxyServiceQuery()
  else:
      query = BusinessServiceQuery()
  query.setPath(path)
  if len(name) > 0:
   query.setLocalName(name)
  else:
   query.setLocalName("*")
  refs=alsbCore.getRefs(query)
  return refs

def getProxyRefs(alsbCore, path, name):
  return getRefs(alsbCore,path,name,true)

def getBizRefs(alsbCore, path, name):
  return getRefs(alsbCore,path,name,false)

def listProxyLevels(refs):
  for serviceRef in refs:
    prxName = serviceRef.getFullName()
    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    isMessageTracingEnabled = str(invoke("isMessageTracingEnabled",objs, strs))
    if (isMessageTracingEnabled == 0):
        isMessageTracingEnabled = "false"
    elif (isMessageTracingEnabled == 1):
        isMessageTracingEnabled = "true"

    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    isLoggingEnabled = str(invoke("isServiceLoggingEnabled",objs, strs))
    
    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    logLevel = str(invoke("getServiceLogLevel",objs, strs))

    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    tracingLevel = str(invoke("getMessageTracingLevel",objs, strs))

    print prxName.ljust(80)+(' tracingEnabled: '+isMessageTracingEnabled).ljust(16)+" tracinglevel: "+tracingLevel+(' loggingEnabled: '+isLoggingEnabled).ljust(18)+" loglevel: "+logLevel

def listBizLevels(refs):
  for serviceRef in refs:
    name = serviceRef.getFullName()
    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    isMessageTracingEnabled = str(invoke("isMessageTracingEnabled",objs, strs))
    if (isMessageTracingEnabled == 0):
        isMessageTracingEnabled = "false"
    elif (isMessageTracingEnabled == 1):
        isMessageTracingEnabled = "true"

    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    tracingLevel = str(invoke("getMessageTracingLevel",objs, strs))

    print name.ljust(80)+(' tracingEnabled: '+isMessageTracingEnabled).ljust(16)+" tracinglevel: "+tracingLevel

def setProxyLevels(refs, proxyLogLevel, proxyTracing, proxyTracingLevel):
  for serviceRef in refs:
    prxName = serviceRef.getFullName()
    if len(proxyTracing) > 0:
        objs = jarray.array([serviceRef, java.lang.Boolean(proxyTracing)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
        invoke("setMessageTracingEnabled",objs, strs)
        print prxName + ' tracing set to ' + proxyTracing 

    if len(proxyTracingLevel) > 0:
        objs = jarray.array([serviceRef, proxyTracingLevel],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','java.lang.String'], java.lang.String )
        invoke("setMessageTracingLevel",objs, strs)
        print prxName + ' Tracing level set to '+proxyTracingLevel

    if len(proxyLogLevel) > 0:
        objs = jarray.array([serviceRef, java.lang.Boolean(true)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
        invoke("setServiceLoggingEnabled",objs, strs)
        print prxName + ' Enabled logging'

    if len(proxyLogLevel) > 0:
        objs = jarray.array([serviceRef, LogSeverityLevel.valueOf(proxyLogLevel)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','com.bea.wli.sb.management.configuration.operations.LogSeverityLevel'], java.lang.String )
        invoke("setServiceLogLevel",objs, strs)
        print prxName + ' Logging level set to '+proxyLogLevel

def setBizLevels(refs, proxyLogLevel, proxyTracing, proxyTracingLevel):
  for serviceRef in refs:
    name = serviceRef.getFullName()
    if len(proxyTracing) > 0:
        objs = jarray.array([serviceRef, java.lang.Boolean(proxyTracing)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
        invoke("setMessageTracingEnabled",objs, strs)
        print name + ' tracing set to ' + proxyTracing 

    if len(proxyTracingLevel) > 0:
        objs = jarray.array([serviceRef, proxyTracingLevel],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','java.lang.String'], java.lang.String )
        invoke("setMessageTracingLevel",objs, strs)
        print name + ' Tracing level set to '+proxyTracingLevel

def getArg(argv, idx):
 if idx < len(sys.argv):
   return sys.argv[idx]
 else:
   return ""

print ''
if len(sys.argv) <= 1:
 print "Invalid number of arguments."
 print 'Usage: setMessageTracingStatus.py -pp <proxypath> -pn <proxyname> -pl <logging level [ERROR|WARNING|DEBUG|INFO]> -pt <turn message tracing off/on [false|true]> -ptl <proxy message tracing level [None|Full|Terse|Headers])'
 exit()
propertiesFile=sys.argv[1]

proxyPath = ""
proxyName = "*"
proxyLogLevel = ""
proxyTracing = ""
proxyTracingLevel = ""
idx = 2
while idx < len(sys.argv):
 a = sys.argv[idx]
 if a == "-pp":
     idx = idx + 1
     proxyPath = getArg(sys.argv, idx)
 elif a == "-pn":
     idx = idx + 1
     proxyName = getArg(sys.argv, idx)
 elif a == "-pl":
     idx = idx + 1
     proxyLogLevel = getArg(sys.argv, idx)
 elif a == "-pt":
     idx = idx + 1
     proxyTracing = getArg(sys.argv, idx)
 elif a == "-ptl":
     idx = idx + 1
     proxyTracingLevel = getArg(sys.argv, idx)
 idx = idx + 1

print "proxyPath = "+proxyPath
print "proxyName = "+proxyName
print "proxyLogLevel = "+proxyLogLevel
print "proxyTracing = "+proxyTracing
print "proxyTracingLevel = "+proxyTracingLevel

loadProperties(propertiesFile)
connect(importUser, importPassword, adminUrl)
domainRuntime()

try:
  print "CGI:Creating session"
  sessionName  = "ChangeLogLevelsSession" + str(System.currentTimeMillis())
  sessionMBean = findService(SessionManagementMBean.NAME, SessionManagementMBean.TYPE)
  sessionMBean.createSession(sessionName)

  alsbCore = findService(ALSBConfigurationMBean.NAME, ALSBConfigurationMBean.TYPE)
  
  if len(proxyPath) > 0:
    print "CGI:Finding proxy services"
    proxyRefs = getProxyRefs(alsbCore, proxyPath, proxyName)
    print "CGI:Finding business services"
    bizRefs = getBizRefs(alsbCore, proxyPath, proxyName)
  else:
    proxyRefs = []
    bizRefs = []

  print "CGI:Changing to custom domain"
  domainCustom()

  cd ("com.bea")
  nomServiceConfigurationMBean = String("ServiceConfiguration.").concat(sessionName)
  cd ("com.bea:Name="+ nomServiceConfigurationMBean +",Location=AdminServer,Type=com.bea.wli.sb.management.configuration.ServiceConfigurationMBean")

  hasProxyLogLevel = len(proxyLogLevel)>0
  hasProxyTracing = len(proxyTracing)>0
  hasproxyTracingLevel = len(proxyTracingLevel)>0
  hasProxyRefs=false
  for i in proxyRefs:
    hasProxyRefs=true
    break

  commitNeeded = hasProxyLogLevel or hasProxyTracing or hasproxyTracingLevel

  if (hasProxyRefs and not(hasProxyLogLevel)):
      print "CGI:Listing proxy levels"
      listProxyLevels(proxyRefs)
      print "CGI:Listing business service levels"
      listBizLevels(bizRefs)

  if (hasProxyRefs and (hasProxyLogLevel or hasProxyTracing)):
      setProxyLevels(proxyRefs, proxyLogLevel, proxyTracing, proxyTracingLevel)
      setBizLevels(bizRefs, proxyLogLevel, proxyTracing, proxyTracingLevel)
    
  if commitNeeded:
    print "CGI:Activating session"
    sessionMBean.activateSession(sessionName,'Changing log levels.')
  else:
    sessionMBean.discardSession(sessionName)
except:
  sessionMBean.discardSession(sessionName)
  print 'Got Error'
  apply(traceback.print_exception, sys.exc_info())
  dumpStack()    



print 'Finished.'
