#!/bin/sh

## Get the absolutepath to installation directory
INSTALLDIR=$(cd $(dirname "$0") && pwd -P)
DATE=`date +%Y_%m_%d_%H\:%M\:%S`
LOGFILE="OSB_install_${DATE}.log"
STATUSFILE=$INSTALLDIR/status
ENV=$1

function usage {
	echo "Usage: ./`basename $0` <dev|preprod|proda|prodb> -pp <Proxy path> [-pn <proxy service name>] [-pl <INFO|ERROR|WARNING|DEBUG>] [-pt <true|false>] [-ptl <Headers|Full|Terse>]";
	echo
	echo "Examples:"
	echo "List logging statuses for proxy services under MobileSOA path" 
	echo "./logging.sh dev -pp MobileSOA/*"
	echo 
	echo "Set MobileSOA/Airport/proxyservices/Airport.proxy logging level to INFo and enable message tracing at level \"Headers\""
	echo "./logging.sh dev -pp MobileSOA/Airport/proxyservices -pn Airport -pl INFO -pt true -ptl Headers"
	echo
	echo "Set logging level to INFO to all proxy services in MoblieSOA path and disable message tracing."
	echo "./logging.sh dev -pp MobileSOA/* -pl INFO -pt false"
	exit
}


COUNT=$#
# Check that enough parameters are given
if [ $COUNT -lt 3 ]; then
	usage;
fi

IDX=0
i=2
while [ $i -le $COUNT ]; do
    eval ARGS[$IDX]=\${$i}
    IDX=$((IDX + 1))
    i=$((i+1))
done

# Check first environment
case "$ENV" in 
dev)
MW_HOME=/home/Oracle/Middleware
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/Oracle_OSB1
;;
preprod)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
proda)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
prodb)
MW_HOME=/weblogic/finnairmw
DOMAIN_HOME=$MW_HOME/user_projects/domains/AYDomain
OSB_HOME=$MW_HOME/FinnairMiddlewareOSB
;;
*)
usage
;;
esac



function log {
	echo `date +"%d.%m.%Y %H:%M:%S": ` "$@"
}

rm $STATUSFILE

{
	log Starting installation
	WLST=$MW_HOME/wlserver_10.3/common/bin/wlst.sh
	log WLST started from: $WLST
	#Set domain env
	. $DOMAIN_HOME/bin/setDomainEnv.sh

	# Execute resource configuration file
	log Executing configuration to WLS
	echo ${ARGS[*]}
	$WLST $INSTALLDIR/logging.py $INSTALLDIR/env/${ENV}.properties ${ARGS[*]} 2>&1 || echo $? > $STATUSFILE
	if [ -f $STATUSFILE ]; then
		log Failed
		exit $CODE;
	fi
	log Finished

} 2>&1 | tee $LOGFILE
if [ -f $STATUSFILE ]; then
	CODE=`cat $STATUSFILE`;
	#rm $STATUSFILE;
	log Installation failed with error code=$CODE
	exit $CODE;
fi
