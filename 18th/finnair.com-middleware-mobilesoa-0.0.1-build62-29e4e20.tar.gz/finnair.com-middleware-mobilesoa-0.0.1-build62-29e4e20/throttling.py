import sys , traceback
from time import sleep
from com.bea.wli.sb.management.configuration import SessionManagementMBean
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.sb.management.configuration import ServiceConfigurationMBean
from com.bea.wli.sb.management.configuration.operations import LogSeverityLevel
from com.bea.wli.sb.management.configuration.operations import PipelineMonitoringLevel
from com.bea.wli.sb.management.query import ProxyServiceQuery
from com.bea.wli.sb.management.query import BusinessServiceQuery
from com.bea.wli.config import Ref

#from com.bea.wli.monitoring import StatisticType
from com.bea.wli.sb.util import Refs

# Call this with proxyRefs=true in order to get only proxy refs
def getRefs(alsbCore, path, name,proxyRefs):
  if (proxyRefs):
      query = ProxyServiceQuery()
  else:
      query = BusinessServiceQuery()
  query.setPath(path)
  if len(name) > 0:
   query.setLocalName(name)
  else:
   query.setLocalName("*")
  refs=alsbCore.getRefs(query)
  return refs

def getProxyRefs(alsbCore, path, name):
  return getRefs(alsbCore,path,name,true)

def getBizRefs(alsbCore, path, name):
  return getRefs(alsbCore,path,name,false)

def listThrottlingLevels(proxyRefs, bizRefs):
  print ""
  print "CGI:Listing business service throttling config"
  print "==================================="
  for serviceRef in bizRefs:
    print serviceRef.toString()
    bizName = serviceRef.getFullName()
    objs = jarray.array([serviceRef],  java.lang.Object)
    strs = jarray.array(['com.bea.wli.config.Ref'], java.lang.String )
    isMonitoringEnabled = str(invoke("isServiceThrottlingEnabled",objs, strs))
    if (isMonitoringEnabled == 0):
        isMonitoringEnabled = "false"
    elif (isMonitoringEnabled == 1):
        isMonitoringEnabled = "true"

    ThrottlingTimeToLive = str(invoke("getServiceThrottlingTimeToLive",objs, strs))
    ThrottlingMaxQueueLength = str(invoke("getServiceThrottlingMaxQueueLength",objs, strs))
    ThrottlingMaxConcurrency = str(invoke("getServiceThrottlingMaxConcurrency",objs, strs))

    print bizName.ljust(80)+(' throttlingEnabled: '+isMonitoringEnabled).ljust(16)+ \
          (' ThrottlingMaxConcurrency: '+ThrottlingMaxConcurrency).ljust(16)+ \
          (' ThrottlingMaxQueueLength: '+ThrottlingMaxQueueLength).ljust(16)+ \
          (' ThrottlingTimeToLive: '+ThrottlingTimeToLive).ljust(16)

# MonitoringLevel=DISABLE|Service|Action|Pipeline
def setThrottlingLevels(proxyRefs, bizRefs, ThrottlingEnable, ThrottlingTimeToLive, ThrottlingMaxQueueLength, ThrottlingMaxConcurrency):
  for serviceRef in bizRefs:
    bizName = serviceRef.getFullName()

    if len(ThrottlingEnable) > 0:
        objs = jarray.array([serviceRef, java.lang.Boolean(ThrottlingEnable)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','boolean'], java.lang.String )
        invoke("setServiceThrottlingEnabled",objs, strs)
        print bizName + ' Throttling='+ThrottlingEnable

    if ThrottlingTimeToLive != "":
        objs = jarray.array([serviceRef, java.lang.Long(ThrottlingTimeToLive)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','long'], java.lang.String )
        invoke("setServiceThrottlingTimeToLive",objs, strs)
        print bizName + ' ThrottlingTimeToLive='+ThrottlingTimeToLive

    if ThrottlingMaxQueueLength != "":
        objs = jarray.array([serviceRef, java.lang.Integer(ThrottlingMaxQueueLength)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','int'], java.lang.String )
        invoke("setServiceThrottlingMaxQueueLength",objs, strs)
        print bizName + ' ThrottlingMaxQueueLength='+ThrottlingMaxQueueLength

    if ThrottlingMaxConcurrency != "":
        objs = jarray.array([serviceRef, java.lang.Long(ThrottlingMaxConcurrency)],  java.lang.Object)
        strs = jarray.array(['com.bea.wli.config.Ref','long'], java.lang.String )
        invoke("setServiceThrottlingMaxConcurrency",objs, strs)
        print bizName + ' ThrottlingMaxConcurrency='+ThrottlingMaxConcurrency


def getArg(argv, idx):
 if idx < len(sys.argv):
   return sys.argv[idx]
 else:
   return ""

print ''
if len(sys.argv) <= 2:
 print "Invalid number of arguments."
 print 'Usage: throttling.py -pp <business service path> -bs <business service name> [-te <Throttling enable [true|false]>] [-tmc <ThrottlingMaxConcurrency>] [-tmq <ThrottlingMaxQueueLength>] [-ttl <ThrottlingTimeToLive>]'
 exit()
propertiesFile=sys.argv[1]

proxyPath = ""
proxyName = "*"
ThrottlingEnable = ""
ThrottlingTimeToLive = 0
ThrottlingMaxQueueLength = 0
ThrottlingMaxConcurrency = 0
idx = 2
while idx < len(sys.argv):
 a = sys.argv[idx]
 if a == "-pp":
     idx = idx + 1
     proxyPath = getArg(sys.argv, idx)
 elif a == "-bs":
     idx = idx + 1
     proxyName = getArg(sys.argv, idx)
 elif a == "-te":
     idx = idx + 1
     ThrottlingEnable = getArg(sys.argv, idx)
 elif a == "-tmc":
     idx = idx + 1
     ThrottlingMaxConcurrency = getArg(sys.argv, idx)
 elif a == "-tmq":
     idx = idx + 1
     ThrottlingMaxQueueLength = getArg(sys.argv, idx)
 elif a == "-ttl":
     idx = idx + 1
     ThrottlingTimeToLive = getArg(sys.argv, idx)
 idx = idx + 1

print "proxyPath = "+proxyPath
print "proxyName = "+proxyName

loadProperties(propertiesFile)
connect(importUser, importPassword, adminUrl)
domainRuntime()

try:
  print "CGI:Creating session"
  sessionName  = "ChangeMonitoringLevelsSession" + str(System.currentTimeMillis())
  sessionMBean = findService(SessionManagementMBean.NAME, SessionManagementMBean.TYPE)
  sessionMBean.createSession(sessionName)

  alsbCore = findService(ALSBConfigurationMBean.NAME, ALSBConfigurationMBean.TYPE)
  
  if len(proxyPath) > 0:
    print "CGI:Finding business services"
    proxyRefs = []
    bizRefs = getBizRefs(alsbCore, proxyPath, proxyName)
  else:
    proxyRefs = []
    bizRefs = []

  hasProxyRefs=false
  for i in proxyRefs:
    hasProxyRefs=true
    break

  hasBizRefs=false
  for i in bizRefs:
    hasBizRefs=true
    break

  print "CGI:Changing to custom domain"
  domainCustom()

  cd ("com.bea")
  nomServiceConfigurationMBean = String("ServiceConfiguration.").concat(sessionName)
  cd ("com.bea:Name="+ nomServiceConfigurationMBean +",Location=AdminServer,Type=com.bea.wli.sb.management.configuration.ServiceConfigurationMBean")

  hasenabledisable = len(ThrottlingEnable)>0

  commitNeeded = hasenabledisable

  if (hasBizRefs and not(hasenabledisable)):
      listThrottlingLevels(proxyRefs,bizRefs)

  if (hasBizRefs and hasenabledisable):
      setThrottlingLevels(proxyRefs, bizRefs, ThrottlingEnable, ThrottlingTimeToLive, ThrottlingMaxQueueLength, ThrottlingMaxConcurrency)

  if commitNeeded:
    print "CGI:Activating session"
    sessionMBean.activateSession(sessionName,'Changing throttling levels.')
  else:
    sessionMBean.discardSession(sessionName)
except:
  sessionMBean.discardSession(sessionName)
  print 'Got Error'
  apply(traceback.print_exception, sys.exc_info())
  dumpStack()    



print 'Finished.'
