#!/bin/sh
ENV=$1

function usage {
	echo "Usage: ./`basename $0` <dev|preprod|proda|prodb>"
	echo
	echo "Examples:"
	echo "Setup logging, monitoring and throttling for MobileSOA related components"
	echo "./setupOperationalSettings.sh dev"
	exit
}


# Check first environment
case "$ENV" in 
dev)
;;
preprod)
;;
proda)
;;
prodb)
;;
*)
usage
;;
esac

#!/bin/sh
./throttling.sh $ENV -pp AmadeusServicesWrapper -bn AmadeusWebServices -te true -tmc 20 -tmq 100 -ttl 60000
./throttling.sh $ENV -pp MobileSOA/Booking/businessservices -bn GetBookingDetailsSplitJoin -te true -tmc 10 -tmq 100 -ttl 60000
./throttling.sh $ENV -pp MobileSOA/Member/businessservices -bn Member -te true -tmc 10 -tmq 100 -ttl 60000

## Setup logging
./monitoring.sh $ENV -pp MobileSOA/* -pl Action
./monitoring.sh $ENV -pp AmadeusServicesWrapper/* -pl Action

## Setup logging
./logging.sh $ENV -pp MobileSOA/* -pl INFO
./logging.sh $ENV -pp AmadeusServicesWrapper/* -pl INFO

